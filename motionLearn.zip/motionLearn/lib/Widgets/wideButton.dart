import 'package:flutter/material.dart';


class WideButton extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Padding();
  }
}
